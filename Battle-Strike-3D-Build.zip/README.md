# Battle Strike 3D — buildable FPS foundation

Original modern military FPS project. It does not copy Call of Duty protected assets, characters, maps, audio, branding, or UI.

Client: `client/index.html`
Server: `server/server.js`

Client features:
3D first-person WebGL arena, mobile controls, ADS, sprint, crouch, reload,
rifle/SMG, recoil, muzzle effect, bots, health/armor, waves, score, minimap-style HUD,
generated audio, and performance limits.

Server features:
WebSocket multiplayer foundation, player sessions, movement validation, shot-rate validation,
join/leave/state messages, and ping handling.

This is a playable foundation, not a finished AAA game. A production-scale game still needs
original high-detail assets/animations, authoritative hitboxes and lag compensation, matchmaking,
accounts, persistence, voice/chat, telemetry, advanced anti-cheat, QA, backend scaling,
and Android/iOS certification.
