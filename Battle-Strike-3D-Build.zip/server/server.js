import {WebSocketServer} from "ws"; import crypto from "crypto";
const port=process.env.PORT||8080, wss=new WebSocketServer({port}), players=new Map();
const send=(w,m)=>w.readyState===1&&w.send(JSON.stringify(m));
const bc=(m,skip)=>players.forEach(p=>{if(p.ws!==skip)send(p.ws,m)});
const ok=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
wss.on("connection",ws=>{const id=crypto.randomUUID(),p={id,ws,x:0,y:1.7,z:0,yaw:0,last:Date.now(),shot:0};players.set(id,p);send(ws,{type:"welcome",id});bc({type:"join",id,x:0,y:1.7,z:0},ws);
ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}
if(m.type==="move"){if(!ok(m.x,-100,100)||!ok(m.y,0,5)||!ok(m.z,-100,100)||!ok(m.yaw,-1000,1000))return;let now=Date.now(),dt=Math.min((now-p.last)/1000,.25),d=Math.hypot(m.x-p.x,m.z-p.z);if(d>Math.max(.8,8.5*dt+.8))return;p.x=m.x;p.y=m.y;p.z=m.z;p.yaw=m.yaw;p.last=now;bc({type:"state",id,x:p.x,y:p.y,z:p.z,yaw:p.yaw},ws)}
else if(m.type==="shot"){let now=Date.now();if(now-p.shot<45)return;p.shot=now;bc({type:"shot",id,weapon:String(m.weapon||"rifle").slice(0,12)},ws)}
else if(m.type==="ping")send(ws,{type:"pong",t:m.t})});
ws.on("close",()=>{players.delete(id);bc({type:"leave",id})})});
console.log("Battle Strike server on",port);